#! /bin/sh

dirname="/home/jet/branches/netflow/nfdump-1.6.9/log"
log_files_to_analyze="appid appgroupid appgroups nameid policyid extrainfoid" 
all_log_files=${log_files_to_analyze}" nfcapd" 

msg_count=''

# Check if LOG dir name look OK !
total_log_files=0
for prefix in $all_log_files
do
	log_file_count=$(ls ${dirname}/${prefix}* 2>/dev/null | wc -l)
    total_log_files=$(expr ${total_log_files} + ${log_file_count}) 	
done
echo Total Log Files = ${total_log_files}
if [ ${total_log_files} == 0 ] ; then
	echo No log files to process in directory ${dirname}
	exit 0
fi

################################################
echo "TEST: FILE COUNT FOR EACH FILE TYPE"
for prefix in $all_log_files
do
	# Beautify the message string (well, really \n is essential for counting lines)
	if [ "${msg_count}" != "" ] ; then
		msg_count="${msg_count}\n"
	fi
	# Count number of files for each file type
	count=$(find ${dirname} -maxdepth 1 -type f -name "${prefix}*" | wc -l)
	# Concetanate the message string
	msg_count="${msg_count} ${count} ${dirname}/${prefix}*"
done
# Finished looping through file counts of each file type
# Now check if they all match
uniqcount=$(echo -e ${msg_count} | awk '{print $1}' | sort | uniq | wc -l)	
if [ $uniqcount == 1 ] ; then
	echo "PASSED. Each file type has ${count} instances"
else
	echo "FAILED! Not all files have same number of instances. Look below -"
	echo -e ${msg_count}
fi
echo "" 
 

################################################
echo "TEST: UNIQUENESS OF INSTANCES OF FILES WITHIN EACH FILE GROUP"
for prefix in $log_files_to_analyze
do
	uniqmd5sums=$(md5sum ${dirname}/${prefix}.* 2>/dev/null | awk '{print $1}' | sort | uniq | wc -l)
	groups=$(echo -n $(md5sum ${dirname}/${prefix}.* | sort -k1 | uniq -w 32 -c | sort -k1 -n | awk '{print $1}'))
	echo "${uniqmd5sums} unique md5sums for ${prefix} Files - Sizes of groups: ${groups}"	
done
echo "" 
